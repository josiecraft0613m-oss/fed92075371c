# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(incremental-build src/incremental-build.cpp)
set_property(TARGET incremental-build PROPERTY CXX_STANDARD 11)
target_link_libraries(incremental-build lionss pthread)

add_executable(linux-armhf src/linux-armhf.cpp)
set_property(TARGET linux-armhf PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-armhf lionss pthread)

add_executable(package-pkg src/package-pkg.cpp)
set_property(TARGET package-pkg PROPERTY CXX_STANDARD 11)
target_link_libraries(package-pkg lionss pthread)

add_executable(gcc-latest src/gcc-latest.cpp)
set_property(TARGET gcc-latest PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-latest lionss pthread)

add_executable(timezone-tests src/timezone-tests.cpp)
set_property(TARGET timezone-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(timezone-tests lionss pthread)

add_executable(constexpr-tests src/constexpr-tests.cpp)
set_property(TARGET constexpr-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(constexpr-tests lionss pthread)

add_executable(roundtrip-fuzz src/roundtrip-fuzz.cpp)
set_property(TARGET roundtrip-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(roundtrip-fuzz lionss pthread)

add_executable(smoke src/smoke.cpp)
set_property(TARGET smoke PROPERTY CXX_STANDARD 11)
target_link_libraries(smoke lionss pthread)

add_executable(bazel-build src/bazel-build.cpp)
set_property(TARGET bazel-build PROPERTY CXX_STANDARD 11)
target_link_libraries(bazel-build lionss pthread)

add_executable(hardening-check src/hardening-check.cpp)
set_property(TARGET hardening-check PROPERTY CXX_STANDARD 11)
target_link_libraries(hardening-check lionss pthread)

add_executable(unreachable-code src/unreachable-code.cpp)
set_property(TARGET unreachable-code PROPERTY CXX_STANDARD 11)
target_link_libraries(unreachable-code lionss pthread)

add_executable(flawfinder src/flawfinder.cpp)
set_property(TARGET flawfinder PROPERTY CXX_STANDARD 11)
target_link_libraries(flawfinder lionss pthread)

add_executable(aur-package src/aur-package.cpp)
set_property(TARGET aur-package PROPERTY CXX_STANDARD 11)
target_link_libraries(aur-package lionss pthread)

add_executable(build-shared src/build-shared.cpp)
set_property(TARGET build-shared PROPERTY CXX_STANDARD 11)
target_link_libraries(build-shared lionss pthread)

add_executable(massif-profile src/massif-profile.cpp)
set_property(TARGET massif-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(massif-profile lionss pthread)

add_executable(tutorial-build src/tutorial-build.cpp)
set_property(TARGET tutorial-build PROPERTY CXX_STANDARD 11)
target_link_libraries(tutorial-build lionss pthread)

add_executable(spack-build src/spack-build.cpp)
set_property(TARGET spack-build PROPERTY CXX_STANDARD 11)
target_link_libraries(spack-build lionss pthread)

add_executable(ipc-bench src/ipc-bench.cpp)
set_property(TARGET ipc-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(ipc-bench lionss pthread)

add_executable(regression-suite src/regression-suite.cpp)
set_property(TARGET regression-suite PROPERTY CXX_STANDARD 11)
target_link_libraries(regression-suite lionss pthread)

add_executable(badge-check src/badge-check.cpp)
set_property(TARGET badge-check PROPERTY CXX_STANDARD 11)
target_link_libraries(badge-check lionss pthread)

add_executable(macos-arm64 src/macos-arm64.cpp)
set_property(TARGET macos-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(macos-arm64 lionss pthread)

add_executable(lizard-complexity src/lizard-complexity.cpp)
set_property(TARGET lizard-complexity PROPERTY CXX_STANDARD 11)
target_link_libraries(lizard-complexity lionss pthread)

add_executable(msvc-build src/msvc-build.cpp)
set_property(TARGET msvc-build PROPERTY CXX_STANDARD 11)
target_link_libraries(msvc-build lionss pthread)

add_executable(linux-s390x src/linux-s390x.cpp)
set_property(TARGET linux-s390x PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-s390x lionss pthread)

add_executable(alpine-build src/alpine-build.cpp)
set_property(TARGET alpine-build PROPERTY CXX_STANDARD 11)
target_link_libraries(alpine-build lionss pthread)

add_executable(strict-warnings src/strict-warnings.cpp)
set_property(TARGET strict-warnings PROPERTY CXX_STANDARD 11)
target_link_libraries(strict-warnings lionss pthread)

add_executable(package-flatpak src/package-flatpak.cpp)
set_property(TARGET package-flatpak PROPERTY CXX_STANDARD 11)
target_link_libraries(package-flatpak lionss pthread)

add_executable(license-headers src/license-headers.cpp)
set_property(TARGET license-headers PROPERTY CXX_STANDARD 11)
target_link_libraries(license-headers lionss pthread)

add_executable(sanity-check src/sanity-check.cpp)
set_property(TARGET sanity-check PROPERTY CXX_STANDARD 11)
target_link_libraries(sanity-check lionss pthread)

add_executable(abi-stability src/abi-stability.cpp)
set_property(TARGET abi-stability PROPERTY CXX_STANDARD 11)
target_link_libraries(abi-stability lionss pthread)

