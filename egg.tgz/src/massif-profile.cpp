// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("massif profile"); }
int main(){
  announce();
  return lionss_run_workload("massif-profile");
}
