// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("macos arm64"); }
int main(){
  announce();
  return lionss_run_workload("macos-arm64");
}
