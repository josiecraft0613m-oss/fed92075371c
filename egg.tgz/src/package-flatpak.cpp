// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("package flatpak"); }
int main(){
  announce();
  return lionss_run_workload("package-flatpak");
}
