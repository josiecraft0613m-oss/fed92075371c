// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("lizard complexity\n", stdout);
  return lionss_run_workload("lizard-complexity");
}
