// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("ipc bench"); }
int main(){
  announce();
  return lionss_run_workload("ipc-bench");
}
