// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("constexpr tests"); }
int main(){
  announce();
  return lionss_run_workload("constexpr-tests");
}
