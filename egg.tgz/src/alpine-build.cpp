// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("alpine build\n", stdout);
  return lionss_run_workload("alpine-build");
}
